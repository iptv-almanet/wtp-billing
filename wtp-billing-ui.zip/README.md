# WTP Billing + WhatsApp

Aplikasi sederhana untuk mengelola pelanggan & tagihan air, dengan integrasi WhatsApp Cloud API.

## Jalankan Lokal
```bash
npm install
cp .env.example .env
npm start
```

## Deploy di Railway
- Push repo ke GitHub
- Hubungkan ke Railway
- Isi Variables (lihat .env.example)
